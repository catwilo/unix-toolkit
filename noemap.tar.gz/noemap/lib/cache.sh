#!/bin/sh
# cache.sh — persistent state cache for noemap
#
# Format: simple KEY=VALUE shell snippet sourced at load time.
# Security: values are validated before sourcing to prevent injection.
#
# Lifecycle:
#   load_cache  — called before detection; populates vars if cache is fresh
#   save_cache  — called after successful detection; persists current state

CACHE="$BASE/state/cache.env"

# Maximum cache age in seconds before it is treated as stale (6 hours)
_CACHE_MAX_AGE=21600

# load_cache — sources the cache file if it exists and is recent enough.
# Uses LAST_SCAN stored in the cache itself (POSIX-portable, no stat -c).
load_cache() {
    [ -f "$CACHE" ] || return 0

    # Read LAST_SCAN from cache for staleness check (avoids GNU-only stat -c)
    _last_scan=0
    while IFS= read -r _line; do
        case "$_line" in
            LAST_SCAN=*) _last_scan="${_line#LAST_SCAN=}" ;;
        esac
    done < "$CACHE"

    _now="$(date +%s 2>/dev/null || echo 0)"
    _age=$(( _now - _last_scan ))

    if [ "$_last_scan" -eq 0 ] || [ "$_age" -gt "$_CACHE_MAX_AGE" ]; then
        log INFO "cache stale (${_age}s old), skipping"
        return 0
    fi

    # Validate and source only safe KEY=VALUE lines.
    while IFS= read -r _line; do
        case "$_line" in
            ''|\#*) continue ;;
        esac

        _key="${_line%%=*}"
        _val="${_line#*=}"

        case "$_key" in
            MY_IP|GW_IP|SUBNET|PRIMARY_IFACE|DEB_IP|LAST_SCAN) ;;
            *) log WARN "cache: unknown key '$_key', skipping"; continue ;;
        esac

        case "$_val" in
            *[\;\`\$\(\)\{\}\|\&\<\>\\\"\'\!]*)
                log WARN "cache: unsafe value for '$_key', skipping"
                continue
                ;;
        esac

        eval "${_key}=\"${_val}\""

    done < "$CACHE"

    log INFO "cache loaded (age: ${_age}s)"
}

# save_cache — atomically writes current state to the cache file.
# Validates that critical variables are non-empty before writing.
save_cache() {
    # Guard: refuse to write if critical vars are empty
    if [ -z "${MY_IP:-}" ] || [ -z "${SUBNET:-}" ]; then
        log WARN "save_cache: MY_IP or SUBNET is empty — cache not updated"
        return 0
    fi

    _ts="$(date +%s 2>/dev/null || echo 0)"

    atomic_write "$CACHE" <<EOF
MY_IP=${MY_IP}
GW_IP=${GW_IP:-}
SUBNET=${SUBNET}
PRIMARY_IFACE=${PRIMARY_IFACE:-}
DEB_IP=${DEB_IP:-}
LAST_SCAN=${_ts}
EOF

    log INFO "cache saved"
}
