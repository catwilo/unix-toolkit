#!/bin/sh
# iface.sh — network interface and subnet detection
#
# Exports:
#   PRIMARY_IFACE  — name of the first usable interface (e.g. eth0, wlan0)
#   MY_IP          — IPv4 address on that interface
#   SUBNET         — CIDR subnet derived from MY_IP + real prefix length
#   GW_IP          — default gateway IP, or .1 of detected subnet as fallback
#
# Strategy:
#   1. Try ip(8) — available on Debian, Arch, modern Termux.
#   2. Fall back to ifconfig — available on older Termux/BSD-style envs.
#   Both paths skip loopback, docker, veth, bridge, tun, wireguard, tailscale.
#
# Subnet detection:
#   Reads the actual prefix length from `ip addr` (e.g. /22, /23, /16).
#   Falls back to /24 assumption only when prefix is unavailable, with a
#   clear warning in the log.

# Interfaces to ignore (prefix match, used in grep -Ev)
_IFACE_SKIP_PATTERN="^(lo|docker|veth|br-|dummy|tailscale|tun|wg|virbr|vmnet)"

# _iface_via_ip — uses ip(8) to find first usable interface+address+prefix.
# Prints "IFACE|IP|PREFIX" or nothing if none found.
_iface_via_ip() {
    ip -4 addr show 2>/dev/null \
    | awk '
        /^[0-9]+: / {
            split($2, a, "@")
            iface = a[1]
            sub(/:$/, "", iface)
        }
        /inet / && iface != "" {
            split($2, b, "/")
            print iface "|" b[1] "|" b[2]
        }
    ' \
    | grep -Ev "$_IFACE_SKIP_PATTERN" \
    | head -1
}

# _iface_via_ifconfig — falls back to ifconfig for older envs.
# Cannot reliably extract prefix length; returns "IFACE|IP|" (empty prefix).
_iface_via_ifconfig() {
    ifconfig 2>/dev/null \
    | awk '
        /^[a-zA-Z0-9]/ {
            iface = $1
            sub(/:$/, "", iface)
        }
        /inet / && $2 != "127.0.0.1" {
            print iface "|" $2 "|"
        }
    ' \
    | grep -Ev "$_IFACE_SKIP_PATTERN" \
    | head -1
}

# _network_addr ip prefix — computes the network address given IP and prefix.
# Uses awk for arithmetic — awk integers are always 64-bit (double precision),
# avoiding the signed 32-bit overflow bug in dash/busybox with 0xFFFFFFFF masks.
_network_addr() {
    printf '%s %s\n' "$1" "$2" | awk '{
        split($1, o, ".")
        ip = (o[1]*16777216) + (o[2]*65536) + (o[3]*256) + o[4]
        pfx = $2
        shift = 32 - pfx
        mask = (shift >= 32) ? 0 : (4294967296 - 2^shift)
        net = int(ip) - (int(ip) % (shift >= 32 ? 1 : 2^shift))
        printf "%d.%d.%d.%d\n",
            int(net/16777216)%256,
            int(net/65536)%256,
            int(net/256)%256,
            net%256
    }'
}

# detect_iface — sets PRIMARY_IFACE and MY_IP.
# Exits with error if no usable interface is found.
detect_iface() {
    _result=""
    _prefix=""

    if has_cmd ip; then
        _result="$(_iface_via_ip)"
    fi

    if [ -z "$_result" ] && has_cmd ifconfig; then
        _result="$(_iface_via_ifconfig)"
    fi

    if [ -z "$_result" ]; then
        log ERROR "no usable network interface found (tried ip and ifconfig)"
        exit 1
    fi

    PRIMARY_IFACE="${_result%%|*}"
    _rest="${_result#*|}"
    MY_IP="${_rest%%|*}"
    _prefix="${_rest##*|}"

    case "$MY_IP" in
        *.*.*.*) ;;
        *)
            log ERROR "unexpected IP format from interface detection: '$MY_IP'"
            exit 1
            ;;
    esac

    # Store prefix for detect_network
    _DETECTED_PREFIX="$_prefix"

    log INFO "interface: $PRIMARY_IFACE  ip: $MY_IP  prefix: ${_prefix:-unknown}"
}

# detect_network — sets SUBNET and GW_IP.
# Requires MY_IP and _DETECTED_PREFIX to be set (call detect_iface first).
detect_network() {
    _pfx="${_DETECTED_PREFIX:-}"

    # Validate prefix is a sane number (8–30)
    case "$_pfx" in
        [89]|[12][0-9]|30) ;;   # valid range
        *)
            if [ -n "$_pfx" ]; then
                log WARN "unusual prefix length /$_pfx — verify your network topology"
            else
                log WARN "could not determine prefix length — assuming /24"
            fi
            _pfx=24
            ;;
    esac

    # Warn explicitly if not /24 so users know the scan scope
    if [ "$_pfx" -ne 24 ]; then
        log WARN "detected /$_pfx network (not /24) — nmap will scan the correct range; nc fallback still uses /24"
    fi

    _net_addr="$(_network_addr "$MY_IP" "$_pfx")"
    SUBNET="${_net_addr}/${_pfx}"

    # Gateway: try ip route, then route -n, then .1 fallback
    GW_IP=""
    if has_cmd ip; then
        GW_IP="$(ip route 2>/dev/null | awk '/^default/ {print $3; exit}')"
    fi

    if [ -z "$GW_IP" ] && has_cmd route; then
        GW_IP="$(route -n 2>/dev/null | awk '/^0\.0\.0\.0/ {print $2; exit}')"
    fi

    if [ -z "$GW_IP" ]; then
        _prefix3="$(printf '%s\n' "$MY_IP" | cut -d. -f1-3)"
        GW_IP="${_prefix3}.1"
        log WARN "could not detect gateway, assuming $GW_IP"
    fi

    log INFO "subnet: $SUBNET  gateway: $GW_IP"
}
