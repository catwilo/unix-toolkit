#!/bin/sh
# lock.sh — session-scoped exclusive lock for noemap
#
# Design:
#   • Lock dir lives under BASE/tmp (session-local, not system /tmp).
#   • Lock dir stores PID so stale locks from crashed runs are recoverable.
#   • acquire_lock detects stale locks (process gone) and cleans them.
#   • release_lock is called by cleanup_session — not directly by callers.
#   • mkdir(1) is atomic on POSIX local filesystems; used as the primitive.

# Path constants (BASE must be set before sourcing)
_LOCK_DIR=""         # Set in acquire_lock after BASE is verified
_LOCK_PID_FILE=""

acquire_lock() {
    _LOCK_DIR="$BASE/tmp/noemap.lock"
    _LOCK_PID_FILE="$_LOCK_DIR/pid"

    # -----------------------------------------------------------------------
    # Stale lock recovery — if lock dir exists but the PID is gone, remove it
    # -----------------------------------------------------------------------
    if [ -d "$_LOCK_DIR" ]; then
        _existing_pid=""
        if [ -f "$_LOCK_PID_FILE" ]; then
            _existing_pid="$(cat "$_LOCK_PID_FILE" 2>/dev/null || true)"
        fi

        _stale=0
        if [ -z "$_existing_pid" ]; then
            # No PID file — lock is from an older version or corrupted
            _stale=1
        elif ! kill -0 "$_existing_pid" 2>/dev/null; then
            # PID file exists but process is not running
            _stale=1
        fi

        if [ "$_stale" -eq 1 ]; then
            log WARN "stale lock found (pid=${_existing_pid:-unknown}), recovering"
            rm -rf "$_LOCK_DIR"
        fi
    fi

    # -----------------------------------------------------------------------
    # Atomic acquisition
    # -----------------------------------------------------------------------
    if ! mkdir "$_LOCK_DIR" 2>/dev/null; then
        _running_pid="$(cat "$_LOCK_PID_FILE" 2>/dev/null || echo unknown)"
        log ERROR "noemap is already running (pid=$_running_pid)"
        exit 1
    fi

    # Write PID into lock dir for stale detection by future runs
    printf '%s\n' "$$" > "$_LOCK_PID_FILE" || {
        # Non-fatal: lock is still held via the directory
        log WARN "could not write PID to lock dir"
    }
}

# release_lock — removes the lock directory.
# Called by cleanup_session (via EXIT trap in util.sh::init_session).
# Safe to call multiple times; idempotent.
release_lock() {
    if [ -n "$_LOCK_DIR" ] && [ -d "$_LOCK_DIR" ]; then
        rm -rf "$_LOCK_DIR"
    fi
    _LOCK_DIR=""
    _LOCK_PID_FILE=""
}
