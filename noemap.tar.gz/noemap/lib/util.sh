#!/bin/sh
# util.sh — shared helpers for the noemap suite
#
# Sourced by noemap and must work under /bin/sh (dash/bash/busybox ash).
# All functions are pure: no side-effects beyond what callers expect.
# No global mutable state except SESSION_TMP_DIR (set once by init_session).

# ---------------------------------------------------------------------------
# Logging — stderr + append to log file
# ---------------------------------------------------------------------------
# log LEVEL message...
# Writes "[LEVEL] message" to stderr and appends to $BASE/logs/noemap.log
# with timestamp. Log rotated at ~200KB.
log() {
    _lvl="$1"
    shift
    _msg="$*"
    _ts="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo '?')"
    printf '[%s] %s\n' "$_lvl" "$_msg" >&2

    # File logging (best-effort: never abort on log failure)
    if [ -n "${BASE:-}" ]; then
        _log="${BASE}/logs/noemap.log"
        # Rotate at ~200KB
        if [ -f "$_log" ] && [ "$(wc -c < "$_log" 2>/dev/null || echo 0)" -gt 204800 ]; then
            mv -f "$_log" "${_log}.1" 2>/dev/null || true
        fi
        printf '%s [%s] %s\n' "$_ts" "$_lvl" "$_msg" >> "$_log" 2>/dev/null || true
    fi
}

# ---------------------------------------------------------------------------
# Command availability
# ---------------------------------------------------------------------------

# has_cmd cmd — returns 0 if cmd is on PATH, 1 otherwise.  No output.
has_cmd() {
    command -v "$1" >/dev/null 2>&1
}

# require_cmd cmd — exits with ERROR if cmd is missing.
# Use for hard dependencies; for soft deps use has_cmd + graceful fallback.
require_cmd() {
    has_cmd "$1" || {
        log ERROR "missing hard dependency: $1 — install it first"
        exit 1
    }
}

# ---------------------------------------------------------------------------
# Session-scoped temp directory
# ---------------------------------------------------------------------------

# SESSION_TMP_DIR is set by init_session (called from noemap main script).
# All temp files must live under this dir so cleanup_session removes them
# atomically, even on abrupt exit.
SESSION_TMP_DIR=""

# init_session — creates the session temp dir and registers EXIT/INT/TERM
# trap.  Must be called exactly once, from the top-level script only.
# Idempotent: safe to call again if SESSION_TMP_DIR already set.
init_session() {
    # Allow override for testing
    if [ -n "$SESSION_TMP_DIR" ] && [ -d "$SESSION_TMP_DIR" ]; then
        return 0
    fi

    # mktemp -d: TMPDIR respected; -t flag differs between GNU/BSD — use
    # the TEMPLATE= positional form which is POSIX-portable.
    SESSION_TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/noemap.XXXXXX")" || {
        log ERROR "cannot create session temp dir in ${TMPDIR:-/tmp}"
        exit 1
    }

    # Trap runs cleanup_session on any exit, including SIGINT and SIGTERM.
    trap 'cleanup_session' EXIT
    trap 'cleanup_session; trap - INT;  kill -INT  "$$"' INT
    trap 'cleanup_session; trap - TERM; kill -TERM "$$"' TERM
}

# cleanup_session — removes the session temp dir if it exists.
cleanup_session() {
    if [ -n "$SESSION_TMP_DIR" ] && [ -d "$SESSION_TMP_DIR" ]; then
        rm -rf "$SESSION_TMP_DIR"
    fi
    SESSION_TMP_DIR=""
}

# session_tmp suffix — prints a new temp-file path inside the session dir.
session_tmp() {
    printf '%s/%s\n' "$SESSION_TMP_DIR" "${1:-tmp}"
}

# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------

# atomic_write target — reads stdin, writes to target atomically via a
# sibling tmp file in the same directory.
atomic_write() {
    _target="$1"
    _dir="$(dirname "$_target")"
    _tmp="${_dir}/.noemap_tmp.$(basename "$_target").$$"

    cat > "$_tmp" || {
        rm -f "$_tmp"
        return 1
    }

    if [ ! -s "$_tmp" ]; then
        rm -f "$_tmp"
        log WARN "atomic_write: empty content, target left intact: $_target"
        return 1
    fi

    mv -f "$_tmp" "$_target" || {
        rm -f "$_tmp"
        log ERROR "atomic_write: mv failed for $_target"
        return 1
    }
}

# ---------------------------------------------------------------------------
# Directory setup
# ---------------------------------------------------------------------------

ensure_dirs() {
    mkdir -p \
        "$BASE/state" \
        "$BASE/logs"  \
        "$BASE/config" \
        "$BASE/tmp"

    # ssh_config points UserKnownHostsFile here; dir must exist before
    # the first SSH connection or OpenSSH refuses to write the file.
    mkdir -p "$HOME/.local/share/noemap"
    chmod 700 "$HOME/.local/share/noemap"
}

# ---------------------------------------------------------------------------
# Env validation — hard and soft dependencies
# FIX: nmap is a soft dep (scan.sh has nc fallback); removed from hard list.
# ---------------------------------------------------------------------------

validate_env() {
    # Hard deps: always required
    for _cmd in awk sed grep cut ping ssh; do
        require_cmd "$_cmd"
    done

    # nmap: strongly recommended but not fatal — scan.sh falls back to nc
    if ! has_cmd nmap; then
        log WARN "nmap not found — host discovery will use nc fallback (port 22 only)"
        log WARN "install nmap for full, reliable discovery"
    fi

    # scp is a soft dep: some systems use sftp-only servers
    if ! has_cmd scp; then
        log WARN "scp not found — nscp will not work; sftp-only environment?"
    fi

    # ifconfig OR ip are needed
    if ! has_cmd ip && ! has_cmd ifconfig; then
        log ERROR "missing hard dependency: ip or ifconfig — install iproute2 or net-tools"
        exit 1
    fi
}

# ---------------------------------------------------------------------------
# Portability helpers
# ---------------------------------------------------------------------------

safe_timeout() {
    _sec="$1"
    shift
    if has_cmd timeout; then
        timeout "$_sec" "$@"
    else
        "$@"
    fi
}

# ---------------------------------------------------------------------------
# known_hosts hygiene
# ---------------------------------------------------------------------------
KNOWN_HOSTS="$HOME/.local/share/noemap/known_hosts"

# known_hosts_remove_ip ip — removes all lines for a given IP from
# known_hosts. Called before registering a host whose IP changed, and
# whenever a fingerprint mismatch is detected.
# Safe to call even if known_hosts does not exist yet.
known_hosts_remove_ip() {
    _ip="$1"
    [ -f "$KNOWN_HOSTS" ] || return 0
    # ssh-keygen -R is the canonical way; it also removes hashed entries.
    if has_cmd ssh-keygen; then
        ssh-keygen -R "$_ip" -f "$KNOWN_HOSTS" >/dev/null 2>&1 || true
    else
        # Fallback: grep out the IP line (plain-text entries only)
        _kh_tmp="${KNOWN_HOSTS}.noemap_tmp.$$"
        grep -v "^${_ip}[ ,]" "$KNOWN_HOSTS" > "$_kh_tmp" 2>/dev/null || true
        mv -f "$_kh_tmp" "$KNOWN_HOSTS" 2>/dev/null || rm -f "$_kh_tmp"
    fi
    log INFO "known_hosts: removed stale entries for $_ip"
}

# known_hosts_sync_device alias old_ip new_ip — called when a device's IP
# changes. Removes the old IP entry so SSH doesn't reject the new one.
known_hosts_sync_device() {
    _alias="$1"
    _old_ip="$2"
    _new_ip="$3"
    if [ "$_old_ip" != "$_new_ip" ]; then
        log INFO "device '$_alias' IP changed: $_old_ip → $_new_ip — cleaning known_hosts"
        known_hosts_remove_ip "$_old_ip"
    fi
}

# known_hosts_prune db_path — removes known_hosts entries for IPs that no
# longer appear in devices.db. Keeps known_hosts from accumulating ghosts
# from DHCP churn.
# Only acts on plain-text (non-hashed) entries.
known_hosts_prune() {
    _db="$1"
    [ -f "$KNOWN_HOSTS" ] || return 0
    [ -f "$_db" ]         || return 0

    # Collect all IPs currently in devices.db
    _live_ips="$(awk -F'|' '
        /^[[:space:]]*$/ { next }
        /^#/             { next }
        NF >= 2          { print $2 }
    ' "$_db" 2>/dev/null)"

    # Read each line of known_hosts; drop lines whose first field (IP or hostname)
    # is not in the live set and looks like a plain IPv4 address we manage.
    _kh_tmp="${KNOWN_HOSTS}.prune_tmp.$$"
    while IFS= read -r _line; do
        case "$_line" in
            ''|\#*) printf '%s\n' "$_line" >> "$_kh_tmp"; continue ;;
        esac
        _entry_host="${_line%% *}"   # first token before space
        # Only prune plain IPv4 addresses (leave hostnames/hashed alone)
        case "$_entry_host" in
            [0-9]*.[0-9]*.[0-9]*.[0-9]*)
                _found=0
                for _lip in $_live_ips; do
                    [ "$_lip" = "$_entry_host" ] && { _found=1; break; }
                done
                [ "$_found" -eq 1 ] && printf '%s\n' "$_line" >> "$_kh_tmp"
                ;;
            *)
                # Non-IP entry: keep unconditionally
                printf '%s\n' "$_line" >> "$_kh_tmp"
                ;;
        esac
    done < "$KNOWN_HOSTS"

    if [ -f "$_kh_tmp" ]; then
        mv -f "$_kh_tmp" "$KNOWN_HOSTS"
        log INFO "known_hosts: pruned stale entries"
    fi
}
