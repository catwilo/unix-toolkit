#!/bin/sh
# scan.sh — host discovery + SSH port probe
#
# Exports:
#   HOST_LIST — newline-separated list of live IPs (SSH reachable)
#
# Strategy:
#   noemap is an SSH device mapper, not a general network scanner.
#   Discovery checks only SSH ports (22, 8022, 2222) so every result
#   is a host you can actually connect to — no router/phone noise.
#
#   Phase 1 — ARP ping via nmap -sn -PR (fast, L2, no routing needed).
#              Falls back to TCP-SYN ping if ARP fails (non-Ethernet).
#   Phase 2 — SSH port probe on discovered IPs (nmap -p or nc fallback).
#              Only hosts with at least one SSH port open are kept.
#
#   After discovery, fingerprinting runs automatically.
#   Use noemap --deep for a broader scan when expected hosts are missing.
#
# Environment:
#   NOEMAP_FULL_PORTS=1  set by noemap --ports; controls output display only
#   NOEMAP_DEEP=1        set by noemap --deep; runs broader phase-1 + phase-2

# SSH ports noemap cares about — the only ports it manages
_SSH_PORTS="22,8022,2222"

# ---------------------------------------------------------------------------
# _nmap_ssh_probe host_file out_file port_list
# Runs nmap port scan, writes results to out_file.
# ---------------------------------------------------------------------------
_nmap_ssh_probe() {
    _hf="$1"; _of="$2"; _ports="$3"
    nmap \
        -Pn \
        -n \
        --host-timeout 4s \
        -p "$_ports" \
        -iL "$_hf" \
        2>/dev/null \
    > "$_of" || true
}

# ---------------------------------------------------------------------------
# _nc_ssh_probe ip — checks if any SSH port is open via nc.
# Prints the first open port number, or nothing.
# ---------------------------------------------------------------------------
_nc_ssh_probe() {
    _h="$1"
    for _p in 22 8022 2222; do
        if nc -z -w 2 "$_h" "$_p" >/dev/null 2>&1; then
            printf '%s\n' "$_p"
            return 0
        fi
    done
}

# ---------------------------------------------------------------------------
# discover_hosts — main entry point. Sets HOST_LIST.
# Set NOEMAP_DEEP=1 (via --deep flag) to run a slower, more thorough scan.
# ---------------------------------------------------------------------------
discover_hosts() {
    log INFO "discovering hosts on $SUBNET"

    _ports="${_SSH_PORTS}"

    _arp_tmp="$(session_tmp arp_out)"
    _ssh_tmp="$(session_tmp ssh_out)"
    _nmap_port_out="$(session_tmp nmap_ports)"

    # -----------------------------------------------------------------------
    # Phase 1: host discovery — ARP ping (fastest, works without root in
    # most Linux kernels; nmap uses raw sockets with cap_net_raw).
    # Falls back to TCP-SYN ping on ports 22,80 if ARP gets no results
    # (can happen on Wi-Fi with AP isolation, or non-Ethernet links).
    # -----------------------------------------------------------------------
    if has_cmd nmap; then
        # Try ARP ping first
        nmap -sn -PR -n --host-timeout 3s "$SUBNET" 2>/dev/null \
            | awk '/Nmap scan report/ {ip=$NF} /Host is up/ {print ip}' \
            > "$_arp_tmp" || true

        # If ARP yielded nothing, fall back to TCP-SYN ping
        if [ ! -s "$_arp_tmp" ]; then
            log INFO "ARP ping returned nothing — trying TCP-SYN ping"
            nmap -sn -PS22,80 -n --host-timeout 3s "$SUBNET" 2>/dev/null \
                | awk '/Nmap scan report/ {ip=$NF} /Host is up/ {print ip}' \
                > "$_arp_tmp" || true
        fi
    else
        # nc fallback: parallel SSH probe across /24
        log WARN "nmap not found — falling back to nc probe (SSH ports only)"
        _base="$(printf '%s\n' "$MY_IP" | cut -d. -f1-3)"
        _nc_tmp="$(session_tmp nc_tmp)"
        : > "$_nc_tmp"
        _jobs=0; _max=16; _i=1
        while [ "$_i" -le 254 ]; do
            _tip="${_base}.${_i}"
            ( _nc_ssh_probe "$_tip" >/dev/null && printf '%s\n' "$_tip" >> "$_nc_tmp" ) &
            _jobs=$(( _jobs + 1 ))
            [ "$_jobs" -lt "$_max" ] || { wait; _jobs=0; }
            _i=$(( _i + 1 ))
        done
        wait
        [ -s "$_nc_tmp" ] && sort -t. -k4 -n "$_nc_tmp" > "$_arp_tmp" || true
    fi

    if [ ! -s "$_arp_tmp" ]; then
        log INFO "no live hosts found on $SUBNET"
        HOST_LIST=""
        return 0
    fi

    _live_count="$(wc -l < "$_arp_tmp" | tr -d ' ')"
    log INFO "phase 1: $_live_count live host(s) found"

    # -----------------------------------------------------------------------
    # Phase 2: SSH port probe — keep only hosts with an SSH port open.
    # This eliminates phones, routers, printers, and ARP-only ghosts.
    # -----------------------------------------------------------------------
    : > "$_ssh_tmp"

    if has_cmd nmap; then
        _nmap_ssh_probe "$_arp_tmp" "$_nmap_port_out" "$_ports"

        # Parse nmap output: keep IPs that have at least one open port
        awk '
            /Nmap scan report for / { cur_ip = $NF; has_open = 0 }
            /open/                  { has_open = 1 }
            /Nmap scan report for / && NR > 1 && prev_has_open { print prev_ip }
            END { if (has_open) print cur_ip }
            { prev_ip = cur_ip; prev_has_open = has_open }
        ' "$_nmap_port_out" > "$_ssh_tmp" || true

        # Fallback parser if the awk above yields nothing but nmap ran fine
        if [ ! -s "$_ssh_tmp" ] && [ -s "$_nmap_port_out" ]; then
            awk -v ports="$_ports" '
                /Nmap scan report for / { ip = $NF; open=0 }
                /\/tcp.*open/           { open=1 }
                /Nmap scan report for / && NR>1 && prev_open { print prev_ip }
                END                     { if (open) print ip }
                { prev_ip=ip; prev_open=open }
            ' "$_nmap_port_out" > "$_ssh_tmp" || true
        fi
    else
        # nc parallel SSH probe on live hosts only
        while IFS= read -r _ip; do
            ( _p="$(_nc_ssh_probe "$_ip")"
              [ -n "$_p" ] && printf '%s\n' "$_ip" >> "$_ssh_tmp" ) &
        done < "$_arp_tmp"
        wait
        # Sort for stable order
        if [ -s "$_ssh_tmp" ]; then
            sort -t. -k4 -n "$_ssh_tmp" > "${_ssh_tmp}.s" && mv "${_ssh_tmp}.s" "$_ssh_tmp" || true
        fi
    fi

    # Exclude self from results
    if [ -s "$_ssh_tmp" ]; then
        _no_self="$(session_tmp ssh_no_self)"
        grep -v "^${MY_IP}$" "$_ssh_tmp" > "$_no_self" 2>/dev/null || true
        mv -f "$_no_self" "$_ssh_tmp"
    fi

    _ssh_count="$(wc -l < "$_ssh_tmp" 2>/dev/null | tr -d ' ')"
    _ssh_count="${_ssh_count:-0}"

    if [ "$_ssh_count" -eq 0 ]; then
        log INFO "no SSH-reachable hosts found (all filtered)"
        HOST_LIST=""
        return 0
    fi

    log INFO "phase 2: $_ssh_count SSH-reachable host(s)"

    # -----------------------------------------------------------------------
    # Deep scan mode (--deep flag): re-run with broader probes before
    # fingerprinting. Finds hosts that missed ARP ping (AP isolation, etc.)
    # -----------------------------------------------------------------------
    if [ "${NOEMAP_DEEP:-0}" = "1" ]; then
        log INFO "deep scan requested — running broader discovery..."

        _deep_tmp="$(session_tmp deep_out)"
        _deep_ports="$(session_tmp deep_ports)"

        if has_cmd nmap; then
            # Deeper: no host-timeout, both ARP and SYN, OS-detection hints
            nmap -sn -PR -PS22,8022,2222,80 -n "$SUBNET" 2>/dev/null \
                | awk '/Nmap scan report/ {ip=$NF} /Host is up/ {print ip}' \
                > "$_deep_tmp" || true

            if [ -s "$_deep_tmp" ]; then
                _nmap_ssh_probe "$_deep_tmp" "$_deep_ports" "$_ports"
                awk '
                    /Nmap scan report for / { cur_ip=$NF; has_open=0 }
                    /open/                  { has_open=1 }
                    /Nmap scan report for / && NR>1 && prev_open { print prev_ip }
                    END { if (has_open) print cur_ip }
                    { prev_ip=cur_ip; prev_open=has_open }
                ' "$_deep_ports" > "$_ssh_tmp" || true
            fi
        else
            # nc deeper: try all 3 SSH ports per host, more workers
            : > "$_ssh_tmp"
            _base="$(printf '%s\n' "$MY_IP" | cut -d. -f1-3)"
            _nc_d="$(session_tmp nc_deep)"
            : > "$_nc_d"
            _j=0; _m=24; _i=1
            while [ "$_i" -le 254 ]; do
                _tip="${_base}.${_i}"
                ( _p="$(_nc_ssh_probe "$_tip")"
                  [ -n "$_p" ] && printf '%s\n' "$_tip" >> "$_nc_d" ) &
                _j=$(( _j+1 ))
                [ "$_j" -lt "$_m" ] || { wait; _j=0; }
                _i=$(( _i+1 ))
            done
            wait
            [ -s "$_nc_d" ] && sort -t. -k4 -n "$_nc_d" > "$_ssh_tmp" || true
        fi

        # Exclude self again after deep scan
        if [ -s "$_ssh_tmp" ]; then
            _no_self2="$(session_tmp ssh_no_self2)"
            grep -v "^${MY_IP}$" "$_ssh_tmp" > "$_no_self2" 2>/dev/null || true
            mv -f "$_no_self2" "$_ssh_tmp"
        fi

        _ssh_count="$(wc -l < "$_ssh_tmp" 2>/dev/null | tr -d ' ')"
        _ssh_count="${_ssh_count:-0}"
        log INFO "deep scan: $_ssh_count SSH-reachable host(s)"
    fi

    HOST_LIST=""
    if [ -s "$_ssh_tmp" ]; then
        HOST_LIST="$(cat "$_ssh_tmp")"
    fi
}
