#!/bin/sh
# fingerprint.sh — SSH port detection and device database management
#
# Reads HOST_LIST (already SSH-filtered by scan.sh).
# Probes open SSH ports (22,8022,2222) per host, classifies type,
# stores to hosts.db.  New host registration (alias + user prompts)
# happens post-display in output.sh → prompt_new_hosts.
#
# Design:
#   • scan.sh already guarantees every IP in HOST_LIST has ≥1 SSH port.
#   • Fast mode (default): type classification via port heuristic only.
#     No banner grabs, no nmap -sV — safe and fast in Termux/no-root.
#   • Deep mode (--deep): adds SSH banner via nmap -sV to distinguish
#     Termux/Android from Debian/Ubuntu on port 22.
#   • Self-IP is excluded (scan.sh filters it, double-checked here).
#   • devices.db is append-only; existing entries never overwritten.
#   • known_hosts cleaned automatically on IP change or removal.

HOSTS_DB="$BASE/state/hosts.db"
DEVICES_DB="$BASE/state/devices.db"

# SSH ports noemap cares about
_FP_SSH_PORTS="22,8022,2222"

# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

_validate_db() {
    _db="$1"
    [ -f "$_db" ] || return 0
    awk -F'|' '
        /^[[:space:]]*$/ { next }
        /^#/             { next }
        NF < 2           { exit 1 }
    ' "$_db"
}

# ---------------------------------------------------------------------------
# SSH port detection per host
# Returns: "PORT" or "" if none open (shouldn't happen post-scan-filter)
# ---------------------------------------------------------------------------
_detect_ssh_port() {
    _ip="$1"
    _fp_nmap_out="$2"   # batch nmap output file (may be empty)

    # Parse from batch nmap output first (fastest)
    if [ -s "$_fp_nmap_out" ]; then
        _p="$(awk -v host="$_ip" '
            /Nmap scan report for / { in_host = ($NF == host) }
            in_host && /\/tcp.*open/ {
                split($1, a, "/")
                print a[1]; exit
            }
        ' "$_fp_nmap_out")"
        [ -n "$_p" ] && { printf '%s\n' "$_p"; return 0; }
    fi

    # nc fallback: probe in order
    for _p in 22 8022 2222; do
        nc -z -w 2 "$_ip" "$_p" >/dev/null 2>&1 && { printf '%s\n' "$_p"; return 0; }
    done
    printf '22\n'   # default; scan.sh confirmed SSH is open somewhere
}

# ---------------------------------------------------------------------------
# _get_ssh_banner ip port — grabs SSH banner via nmap -sV (slow, root-free).
# Only called in --deep mode. Prints the version line or empty on failure.
# ---------------------------------------------------------------------------
_get_ssh_banner() {
    _bip="$1"; _bport="$2"
    has_cmd nmap || return 0
    nmap -Pn -n -sV --version-intensity 0 \
        --host-timeout 5s -p "$_bport" "$_bip" 2>/dev/null \
    | awk '/open.*ssh/{ print; exit }'
}

# ---------------------------------------------------------------------------
# Type classification
#
# Fast mode (default): port heuristic only — no extra probes, no nmap -sV.
#   8022  → android-ssh  (Termux default port)
#   2222  → linux-ssh    (common non-root Linux sshd)
#   22    → linux-ssh    (generic; may be Termux — use --deep to distinguish)
#
# Deep mode (NOEMAP_DEEP=1): adds SSH banner grab via nmap -sV to tell
#   apart a Termux device on port 22 (no distro tag) from real Debian/Ubuntu.
#
# Args: $1=ttl  $2=ssh_port  $3=unused  $4=ip (deep mode banner only)
# ---------------------------------------------------------------------------
_detect_type() {
    _ttl="$1"; _ssh_port="$2"; _ip="${4:-}"

    case "$_ttl" in
        128|127) printf 'windows'; return ;;
        255)     printf 'router';  return ;;
    esac

    [ -z "$_ssh_port" ] && { printf 'linux'; return; }

    case "$_ssh_port" in
        8022) printf 'android-ssh'; return ;;
        2222) printf 'linux-ssh';   return ;;
    esac

    # Port 22 — fast mode stops here (no banner, no extra probe)
    if [ "${NOEMAP_DEEP:-0}" != "1" ] || [ -z "$_ip" ]; then
        printf 'linux-ssh'; return
    fi

    # Deep mode only: grab banner to distinguish Termux from Debian/Ubuntu/etc.
    _banner="$(_get_ssh_banner "$_ip" "$_ssh_port" 2>/dev/null || true)"
    case "$_banner" in
        *[Uu]buntu*|*[Dd]ebian*|*[Aa]lpine*|*[Aa]rch*|*[Ff]edora*|*[Rr]aspbian*)
            printf 'linux-ssh'   ;;
        *[Oo]pen[Ss][Ss][Hh]*)
            printf 'android-ssh' ;;   # Generic banner, no distro → likely Termux
        *)
            printf 'linux-ssh'   ;;   # Banner grab failed — safe default
    esac
}

# ---------------------------------------------------------------------------
# fingerprint_hosts — main entry point
# ---------------------------------------------------------------------------
fingerprint_hosts() {
    log INFO "fingerprinting ${HOST_LIST:+$(printf '%s\n' "$HOST_LIST" | wc -l | tr -d ' ')} host(s)"

    _hosts_partial="$(session_tmp hosts_partial)"
    : > "$_hosts_partial"
    DEB_IP=""

    [ -n "${HOST_LIST:-}" ] || {
        log INFO "no hosts to fingerprint"
        return 0
    }

    # -----------------------------------------------------------------------
    # Batch SSH port scan across all discovered hosts
    # -----------------------------------------------------------------------
    _fp_nmap_out="$(session_tmp fp_nmap_out)"
    if has_cmd nmap; then
        _fp_host_file="$(session_tmp fp_hosts)"
        printf '%s\n' "$HOST_LIST" > "$_fp_host_file"
        nmap -Pn -n --host-timeout 4s -p "$_FP_SSH_PORTS" \
            -iL "$_fp_host_file" 2>/dev/null > "$_fp_nmap_out" || true
    fi

    # -----------------------------------------------------------------------
    # Per-host: TTL + SSH port → classify + record
    # -----------------------------------------------------------------------
    printf '%s\n' "$HOST_LIST" | while IFS= read -r _ip; do
        [ -n "$_ip" ] || continue
        [ "$_ip" = "$MY_IP" ] && continue   # skip self (double-check)

        # TTL via ping
        _ttl=""
        _ttl_raw="$(ping -c 1 -W 1 "$_ip" 2>/dev/null || true)"
        case "$_ttl_raw" in
            *[Tt][Tt][Ll]=*)
                _ttl="$(printf '%s\n' "$_ttl_raw" \
                    | sed -n 's/.*[Tt][Tt][Ll]=\([0-9]*\).*/\1/p' | head -1)" ;;
        esac

        # SSH port
        _ssh_port="$(_detect_ssh_port "$_ip" "$_fp_nmap_out")"

        # All open ports (for display in --ports mode)
        _all_ports=""
        if [ -s "$_fp_nmap_out" ]; then
            _all_ports="$(awk -v host="$_ip" '
                /Nmap scan report for / { in_host = ($NF == host) }
                in_host && /\/tcp.*open/ {
                    split($1, a, "/"); printf "%s,", a[1]
                }
            ' "$_fp_nmap_out" | sed 's/,$//')"
        fi

        # Type: fast mode = port only; deep mode = port + banner
        _type="$(_detect_type "${_ttl:-}" "$_ssh_port" "" "$_ip")"

        log INFO "host $_ip  ttl=${_ttl:-?}  ssh=${_ssh_port:-none}  ports=${_all_ports:-none}  type=$_type"

        # Format: IP|TYPE|TTL|SSH_PORT|ALL_PORTS
        printf '%s|%s|%s|%s|%s\n' \
            "$_ip" "$_type" "${_ttl:-0}" "${_ssh_port:-22}" "${_all_ports:-}" \
            >> "$_hosts_partial"

        if [ "$_type" = "linux-ssh" ]; then
            _deb_marker="$(session_tmp deb_ip)"
            [ -f "$_deb_marker" ] || printf '%s\n' "$_ip" > "$_deb_marker"
        fi
    done

    # Promote hosts.db atomically
    if [ -s "$_hosts_partial" ]; then
        if _validate_db "$_hosts_partial"; then
            atomic_write "$HOSTS_DB" < "$_hosts_partial"
        else
            log WARN "fingerprint validation failed — hosts.db left intact"
        fi
    fi

    # Recover DEB_IP from marker (subshell barrier)
    _deb_marker="$(session_tmp deb_ip)"
    [ -f "$_deb_marker" ] && DEB_IP="$(cat "$_deb_marker")"

    # Update ports for already-registered hosts; leave new hosts for prompt
    [ -f "$DEVICES_DB" ] || touch "$DEVICES_DB"
    [ -s "$_hosts_partial" ] && _register_new_hosts "$_hosts_partial"

    # Prune stale known_hosts
    known_hosts_prune "$DEVICES_DB"
}

# ---------------------------------------------------------------------------
# _register_new_hosts — update SSH port for already-registered IPs if changed.
# New host registration (alias + user prompts) moves to output.sh
# → prompt_new_hosts, which runs after the full table is displayed.
# ---------------------------------------------------------------------------
_register_new_hosts() {
    _partial="$1"

    while IFS='|' read -r _ip _type _ttl _ssh_port _all_ports; do
        [ -n "$_ip" ] || continue

        _existing="$(awk -F'|' -v ip="$_ip" '
            /^[[:space:]]*$/ { next }
            /^#/             { next }
            $2 == ip         { print $1; exit }
        ' "$DEVICES_DB" 2>/dev/null)"

        [ -n "$_existing" ] || continue   # new host — handled by prompt_new_hosts

        _cur_port="$(awk -F'|' -v ip="$_ip" '
            /^[[:space:]]*$/ { next }
            /^#/             { next }
            $2 == ip         { print $4; exit }
        ' "$DEVICES_DB" 2>/dev/null)"
        _cur_port="${_cur_port:-22}"

        if [ -n "$_ssh_port" ] && [ "$_ssh_port" != "$_cur_port" ]; then
            _tmp_db="$(mktemp "${TMPDIR:-/tmp}/ndevs.XXXXXX")"
            awk -F'|' -v ip="$_ip" -v np="$_ssh_port" '
                /^[[:space:]]*$/ { print; next }
                /^#/             { print; next }
                $2 == ip         { printf "%s|%s|%s|%s\n",$1,$2,$3,np; next }
                { print }
            ' "$DEVICES_DB" > "$_tmp_db"
            mv -f "$_tmp_db" "$DEVICES_DB"
            log INFO "updated SSH port for '$_existing': $_cur_port → $_ssh_port"
        else
            log INFO "host $_ip already registered as '$_existing'"
        fi
    done < "$_partial"
}

# ---------------------------------------------------------------------------
# new_hosts_list — prints IPs from hosts.db not yet in devices.db.
# Used by prompt_new_hosts in output.sh.
# ---------------------------------------------------------------------------
new_hosts_list() {
    _hdb="$HOSTS_DB"
    _ddb="$DEVICES_DB"
    [ -f "$_hdb" ] && [ -s "$_hdb" ] || return 0

    while IFS='|' read -r _ip _type _ttl _ssh_port _all_ports; do
        [ -n "$_ip" ] || continue
        _found="$(awk -F'|' -v ip="$_ip" '
            /^[[:space:]]*$/ { next }
            /^#/             { next }
            $2 == ip         { print 1; exit }
        ' "$_ddb" 2>/dev/null)"
        [ -z "$_found" ] && printf '%s|%s|%s\n' "$_ip" "$_type" "${_ssh_port:-22}"
    done < "$_hdb"
}
