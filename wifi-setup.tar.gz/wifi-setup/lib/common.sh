#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
umask 077

BASE_DIR="/opt/wifi-setup"
LOG_DIR="${BASE_DIR}/logs"
STATE_DIR="${BASE_DIR}/state"
CONFIG_DIR="${BASE_DIR}/config"

require_dirs() {
    mkdir -p "${LOG_DIR}" "${STATE_DIR}" "${CONFIG_DIR}"
    chmod 700 "${LOG_DIR}" "${STATE_DIR}" "${CONFIG_DIR}"
}

trap 'rm -f /tmp/wifisetup.*' EXIT INT TERM

require_root() {
    if [[ "${EUID}" -ne 0 ]]; then
        echo "error: debe ejecutarse como root" >&2
        exit 1
    fi
}

validate_interface() {
    local iface="$1"
    if ! ip link show "${iface}" >/dev/null 2>&1; then
        echo "error: interfaz '${iface}' no encontrada" >&2
        return 1
    fi
}

log() {
    local level="$1"; shift
    local msg="[$(date '+%Y-%m-%dT%H:%M:%S')] [${level}] $*"
    echo "${msg}" >&2
    mkdir -p "${LOG_DIR}" && echo "${msg}" >> "${LOG_DIR}/wifi-setup.log"
}

backup_file() {
    [[ -f "$1" ]] && cp -a "$1" "$1.bak"
}

rollback_network() {
    if [[ -f "$1" ]]; then
        cp -f "$1" "$2"
        log "INFO" "rolled back config: $2"
    fi
}
