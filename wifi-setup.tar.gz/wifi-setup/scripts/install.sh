#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/common.sh"

require_root

# ---------------------------------------------------------------------------
# Dependency map: command -> apt package (minimal, stable, no recommends)
# wpasupplicant  -> wpa_passphrase + wpa_supplicant
# iproute2       -> ip
# network-manager-> nmcli  (only if already installed; not forced)
# isc-dhcp-client-> dhclient
# ---------------------------------------------------------------------------
declare -A DEPS=(
    [wpa_passphrase]="wpasupplicant"
    [ip]="iproute2"
    [dhclient]="isc-dhcp-client"
)

_apt_ready=0
ensure_apt() {
    if [[ "${_apt_ready}" -eq 0 ]]; then
        apt-get update -qq
        _apt_ready=1
    fi
}

install_dep() {
    local cmd="$1" pkg="$2"
    if ! command -v "${cmd}" >/dev/null 2>&1; then
        log "INFO" "instalando dependencia: ${pkg} (para ${cmd})"
        ensure_apt
        apt-get install -y --no-install-recommends "${pkg}"
    else
        log "INFO" "dependencia ok: ${cmd}"
    fi
}

for cmd in "${!DEPS[@]}"; do
    install_dep "${cmd}" "${DEPS[$cmd]}"
done

# nmcli: only install network-manager if no other network manager is active,
# to avoid displacing dhcpcd/systemd-networkd on minimal systems
if ! command -v nmcli >/dev/null 2>&1; then
    # Check if NM is actually needed (wifi-list/status/showpass use it with || fallbacks)
    log "INFO" "nmcli no encontrado — instalando network-manager"
    ensure_apt
    apt-get install -y --no-install-recommends network-manager
else
    log "INFO" "dependencia ok: nmcli"
fi

# ---------------------------------------------------------------------------
# Idempotent directory setup
# ---------------------------------------------------------------------------
INSTALL_DIR="/opt/wifi-setup"
require_dirs
mkdir -p "${INSTALL_DIR}"/{bin,lib,config,state,logs}
chmod 700 "${INSTALL_DIR}"/config "${INSTALL_DIR}"/logs "${INSTALL_DIR}"/state

# ---------------------------------------------------------------------------
# Copy files (idempotent — cp -a overwrites cleanly)
# ---------------------------------------------------------------------------
cp -a "${SCRIPT_DIR}/../bin/." "${INSTALL_DIR}/bin/"
cp -a "${SCRIPT_DIR}/../lib/." "${INSTALL_DIR}/lib/"

# ---------------------------------------------------------------------------
# Per-interface config — skip if already exists (idempotent)
# ---------------------------------------------------------------------------
found=0
for iface_path in /sys/class/net/wl* /sys/class/net/wlan*; do
    [[ -e "${iface_path}" ]] || continue
    iface="${iface_path##*/}"
    conf="${INSTALL_DIR}/config/${iface}.conf"
    found=1

    if [[ -f "${conf}" ]]; then
        log "INFO" "config ya existe para ${iface} — sin cambios"
        continue
    fi

    read -r -p "SSID para ${iface} [cursed]: " ssid
    ssid="${ssid:-cursed}"

    while true; do
        read -r -s -p "WPA password (min 8): " passwd
        echo
        [[ "${#passwd}" -ge 8 ]] && break
        echo "error: mínimo 8 caracteres" >&2
    done

    psk_line="$(wpa_passphrase "${ssid}" "${passwd}" \
        | grep -E '^\s+psk=' | grep -v '#' | tr -d '\t ')"
    unset passwd

    cat <<EOF2 > "${conf}"
network={
    ssid="${ssid}"
    ${psk_line}
}
EOF2
    chmod 600 "${conf}"
    log "INFO" "config creada para ${iface} (ssid: ${ssid})"
done

[[ "${found}" -eq 0 ]] && log "WARN" "no se encontraron interfaces wireless"

# ---------------------------------------------------------------------------
# Symlinks — idempotent via ln -sf
# ---------------------------------------------------------------------------
for bin in wifi-list wifi-status wifi-passwd wifi-panic wifi-showpass; do
    ln -sf "${INSTALL_DIR}/bin/${bin}" "/usr/local/bin/${bin}"
done

log "INFO" "instalación completa"
echo "--- resumen ---"
find "${INSTALL_DIR}" -maxdepth 2
