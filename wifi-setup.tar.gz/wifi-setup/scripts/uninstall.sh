#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/common.sh"

require_root

for bin in wifi-list wifi-status wifi-passwd wifi-panic wifi-showpass; do
    rm -f "/usr/local/bin/${bin}"
done

log "INFO" "symlinks eliminados"
echo "ok: uninstall completo. /opt/wifi-setup preservado — elimínalo manualmente si lo deseas."
